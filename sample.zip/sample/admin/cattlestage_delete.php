<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "regform";
$errors = array(); 
$conn = mysqli_connect($servername, $username, $password, $dbname);
if(!empty($_GET['cid']))
{
$reslt = mysqli_query($conn,"DELETE FROM `cattlestage` WHERE cid='".$_GET['cid']."'");
echo "deleted successfully";
}
else
{
	header("location:dashboard.php");
}
?>