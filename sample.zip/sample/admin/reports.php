<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "regform";
$errors = array(); 
include("index.php");  
?>
<div class="page-wrapper">

     <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-12 d-flex no-block align-items-center">
                        <h3 class="page-title">Reports</h3>
						</div>
						</div>
						</div>
  <div class="container-fluid">
<div class="row">
                    <div class="col-md-8">
                        
 <div class="card-body">
<a class="btn btn-primary" href="reportsuppliers.php">Suppliers</a>
<a class="btn btn-primary" href="reportmilk.php">milk</a>
<a class="btn btn-primary" href="reportemployee.php">employee</a>
<a class="btn btn-primary" href="reportsales.php">sales</a>
<a class="btn btn-primary" href="reportcattle.php">Cattle</a>
<a class="btn btn-primary" href="reportstock.php">Stock</a>
<a class="btn btn-primary" href="reportsissuse.php">Issuse</a>
</div>
				
			</div>
		</div>
	</div>
</div>