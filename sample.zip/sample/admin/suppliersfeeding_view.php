<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "regform";
$errors = array(); 
$conn = mysqli_connect($servername, $username, $password, $dbname);

$reslt = mysqli_query($conn,"SELECT * FROM `suppliersfeeding` where (suppliersname ='".$_GET['supplier']."' AND location like '%".$_GET['location']."%' )");
$res= mysqli_fetch_array($reslt);
echo $res['quantity'];
?>