<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "regform";
$errors = array(); 
include("index.php");  
?>
<div class="page-wrapper">

     <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-12 d-flex no-block align-items-center">
                        <h4 class="page-title">Production</h4>
						</div>
						</div>
						</div>
  <div class="container-fluid">
<div class="row">
                    <div class="col-md-8">
                        
 <div class="card-body">
<a class="btn btn-primary" href="productionmilk.php">Production Milk</a>
<a class="btn btn-primary" href="productionfeeding.php">production feeding</a>
</div>
				
			</div>
		</div>
	</div>
</div>