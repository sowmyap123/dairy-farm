<?php
include('db.php');
include('menu.php');
?>

<h1>Bulk Products</h1>

<h3>Near by stores</h3>
