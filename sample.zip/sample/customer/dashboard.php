<?php
	include("index.php"); 
	?>
	
<div class="page-wrapper">

          <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-12 d-flex no-block align-items-center">
                        <h4 class="page-title"> Customer Dashboard</h4>
                        <div class="ml-auto text-right">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Library</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Sales Cards  -->
                <!-- ============================================================== -->
                <div class="row">
                    <!-- Column -->
      
					 <div class="col-md-6 col-lg-2 col-xlg-3">
                        <div class="card card-hover">
                             <a href="individual.php"> <div class="box bg-info text-center">
                                <h1 class="font-light text-white"><i class="mdi mdi-equal-box"></i></h1>
                                <h6 class="text-white">For Individual Products</h6>
                            </div>
                        </div></a>
                    </div>
					
						  <div class="col-md-6 col-lg-4 col-xlg-3">
                       <div class="card card-hover">
                              <a href="bulk.php"><div class="box bg-success text-center">
                               <h1 class="font-light text-white"><i class="mdi mdi-equal-box"></i></h1>
                                <h6 class="text-white">For Bulk products</h6>
                            </div>
                        </div></a>
                    </div>
	<!---				
	  <li><a href="individual.php">For individual products</a></li>
	    <li><a href="Bulk.php">For Bulk products</a></li>
	 -->
	  </div>
	  </div>
	               </div>
               
         
  
		